```python
import pandas as pd
```


```python
data = pd.read_csv('vaccination-data.csv')
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_code</th>
      <th>continent</th>
      <th>location</th>
      <th>date</th>
      <th>total_cases</th>
      <th>new_cases</th>
      <th>new_cases_smoothed</th>
      <th>total_deaths</th>
      <th>new_deaths</th>
      <th>new_deaths_smoothed</th>
      <th>...</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
      <th>excess_mortality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-24</td>
      <td>5.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-25</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-26</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-27</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-28</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-29</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.714</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-01</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.714</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-02</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-03</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-04</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 62 columns</p>
</div>




```python
data.info
```




    <bound method DataFrame.info of        iso_code continent     location        date  total_cases  new_cases  \
    0           AFG      Asia  Afghanistan  2020-02-24          5.0        5.0   
    1           AFG      Asia  Afghanistan  2020-02-25          5.0        0.0   
    2           AFG      Asia  Afghanistan  2020-02-26          5.0        0.0   
    3           AFG      Asia  Afghanistan  2020-02-27          5.0        0.0   
    4           AFG      Asia  Afghanistan  2020-02-28          5.0        0.0   
    ...         ...       ...          ...         ...          ...        ...   
    118129      ZWE    Africa     Zimbabwe  2021-09-16     127368.0      285.0   
    118130      ZWE    Africa     Zimbabwe  2021-09-17     127632.0      264.0   
    118131      ZWE    Africa     Zimbabwe  2021-09-18     127739.0      107.0   
    118132      ZWE    Africa     Zimbabwe  2021-09-19     127938.0      199.0   
    118133      ZWE    Africa     Zimbabwe  2021-09-20     128186.0      248.0   
    
            new_cases_smoothed  total_deaths  new_deaths  new_deaths_smoothed  \
    0                      NaN           NaN         NaN                  NaN   
    1                      NaN           NaN         NaN                  NaN   
    2                      NaN           NaN         NaN                  NaN   
    3                      NaN           NaN         NaN                  NaN   
    4                      NaN           NaN         NaN                  NaN   
    ...                    ...           ...         ...                  ...   
    118129             187.429        4560.0         9.0                5.571   
    118130             209.857        4562.0         2.0                4.286   
    118131             217.000        4563.0         1.0                3.857   
    118132             238.429        4567.0         4.0                4.143   
    118133             255.286        4569.0         2.0                3.714   
    
            ...  extreme_poverty  cardiovasc_death_rate  diabetes_prevalence  \
    0       ...              NaN                597.029                 9.59   
    1       ...              NaN                597.029                 9.59   
    2       ...              NaN                597.029                 9.59   
    3       ...              NaN                597.029                 9.59   
    4       ...              NaN                597.029                 9.59   
    ...     ...              ...                    ...                  ...   
    118129  ...             21.4                307.846                 1.82   
    118130  ...             21.4                307.846                 1.82   
    118131  ...             21.4                307.846                 1.82   
    118132  ...             21.4                307.846                 1.82   
    118133  ...             21.4                307.846                 1.82   
    
            female_smokers  male_smokers  handwashing_facilities  \
    0                  NaN           NaN                  37.746   
    1                  NaN           NaN                  37.746   
    2                  NaN           NaN                  37.746   
    3                  NaN           NaN                  37.746   
    4                  NaN           NaN                  37.746   
    ...                ...           ...                     ...   
    118129             1.6          30.7                  36.791   
    118130             1.6          30.7                  36.791   
    118131             1.6          30.7                  36.791   
    118132             1.6          30.7                  36.791   
    118133             1.6          30.7                  36.791   
    
            hospital_beds_per_thousand  life_expectancy  human_development_index  \
    0                              0.5            64.83                    0.511   
    1                              0.5            64.83                    0.511   
    2                              0.5            64.83                    0.511   
    3                              0.5            64.83                    0.511   
    4                              0.5            64.83                    0.511   
    ...                            ...              ...                      ...   
    118129                         1.7            61.49                    0.571   
    118130                         1.7            61.49                    0.571   
    118131                         1.7            61.49                    0.571   
    118132                         1.7            61.49                    0.571   
    118133                         1.7            61.49                    0.571   
    
            excess_mortality  
    0                    NaN  
    1                    NaN  
    2                    NaN  
    3                    NaN  
    4                    NaN  
    ...                  ...  
    118129               NaN  
    118130               NaN  
    118131               NaN  
    118132               NaN  
    118133               NaN  
    
    [118134 rows x 62 columns]>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_cases</th>
      <th>new_cases</th>
      <th>new_cases_smoothed</th>
      <th>total_deaths</th>
      <th>new_deaths</th>
      <th>new_deaths_smoothed</th>
      <th>total_cases_per_million</th>
      <th>new_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>total_deaths_per_million</th>
      <th>...</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
      <th>excess_mortality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.122870e+05</td>
      <td>112284.000000</td>
      <td>111269.00000</td>
      <td>1.015910e+05</td>
      <td>101746.000000</td>
      <td>111269.000000</td>
      <td>111695.000000</td>
      <td>111692.000000</td>
      <td>110682.000000</td>
      <td>101012.000000</td>
      <td>...</td>
      <td>70510.000000</td>
      <td>104688.000000</td>
      <td>107869.000000</td>
      <td>81759.000000</td>
      <td>80571.00000</td>
      <td>52591.000000</td>
      <td>95208.000000</td>
      <td>112063.000000</td>
      <td>104783.000000</td>
      <td>4200.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.379209e+06</td>
      <td>6444.293604</td>
      <td>6460.83749</td>
      <td>3.527951e+04</td>
      <td>145.840407</td>
      <td>132.717676</td>
      <td>17012.999969</td>
      <td>82.161840</td>
      <td>82.149499</td>
      <td>358.867428</td>
      <td>...</td>
      <td>13.468047</td>
      <td>259.164091</td>
      <td>8.005347</td>
      <td>10.597073</td>
      <td>32.73206</td>
      <td>50.750972</td>
      <td>3.024735</td>
      <td>73.258832</td>
      <td>0.726640</td>
      <td>18.565074</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.257933e+06</td>
      <td>39388.591512</td>
      <td>38973.27834</td>
      <td>2.103508e+05</td>
      <td>795.227615</td>
      <td>743.599984</td>
      <td>29307.116642</td>
      <td>192.036166</td>
      <td>162.367045</td>
      <td>614.177243</td>
      <td>...</td>
      <td>19.978613</td>
      <td>119.296466</td>
      <td>4.266206</td>
      <td>10.506520</td>
      <td>13.50011</td>
      <td>31.753830</td>
      <td>2.453752</td>
      <td>7.544245</td>
      <td>0.150252</td>
      <td>34.934536</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000e+00</td>
      <td>-74347.000000</td>
      <td>-6223.00000</td>
      <td>1.000000e+00</td>
      <td>-1918.000000</td>
      <td>-232.143000</td>
      <td>0.001000</td>
      <td>-3125.829000</td>
      <td>-272.971000</td>
      <td>0.001000</td>
      <td>...</td>
      <td>0.100000</td>
      <td>79.370000</td>
      <td>0.990000</td>
      <td>0.100000</td>
      <td>7.70000</td>
      <td>1.188000</td>
      <td>0.100000</td>
      <td>53.280000</td>
      <td>0.394000</td>
      <td>-95.590000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.872000e+03</td>
      <td>3.000000</td>
      <td>9.00000</td>
      <td>6.500000e+01</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>327.393500</td>
      <td>0.275000</td>
      <td>1.507000</td>
      <td>9.925000</td>
      <td>...</td>
      <td>0.600000</td>
      <td>168.711000</td>
      <td>5.310000</td>
      <td>1.900000</td>
      <td>21.60000</td>
      <td>19.351000</td>
      <td>1.300000</td>
      <td>67.920000</td>
      <td>0.602000</td>
      <td>0.910000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.919500e+04</td>
      <td>90.000000</td>
      <td>111.57100</td>
      <td>5.770000e+02</td>
      <td>2.000000</td>
      <td>1.571000</td>
      <td>2560.346000</td>
      <td>10.358500</td>
      <td>14.147000</td>
      <td>65.212500</td>
      <td>...</td>
      <td>2.200000</td>
      <td>243.811000</td>
      <td>7.110000</td>
      <td>6.300000</td>
      <td>31.40000</td>
      <td>49.839000</td>
      <td>2.400000</td>
      <td>74.620000</td>
      <td>0.744000</td>
      <td>8.080000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.034785e+05</td>
      <td>909.000000</td>
      <td>960.14300</td>
      <td>4.952000e+03</td>
      <td>19.000000</td>
      <td>15.429000</td>
      <td>20077.397000</td>
      <td>79.823250</td>
      <td>89.090250</td>
      <td>430.085750</td>
      <td>...</td>
      <td>21.200000</td>
      <td>329.942000</td>
      <td>10.080000</td>
      <td>19.300000</td>
      <td>41.10000</td>
      <td>82.502000</td>
      <td>3.861000</td>
      <td>78.740000</td>
      <td>0.848000</td>
      <td>24.690000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.290813e+08</td>
      <td>906034.000000</td>
      <td>826428.57100</td>
      <td>4.700003e+06</td>
      <td>17976.000000</td>
      <td>14723.000000</td>
      <td>211919.927000</td>
      <td>8620.690000</td>
      <td>3385.473000</td>
      <td>5967.311000</td>
      <td>...</td>
      <td>77.600000</td>
      <td>724.417000</td>
      <td>30.530000</td>
      <td>44.000000</td>
      <td>78.10000</td>
      <td>100.000000</td>
      <td>13.800000</td>
      <td>86.750000</td>
      <td>0.957000</td>
      <td>411.260000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 57 columns</p>
</div>




```python

my_list = [i for i in data]
print(my_list)
```

    ['iso_code', 'continent', 'location', 'date', 'total_cases', 'new_cases', 'new_cases_smoothed', 'total_deaths', 'new_deaths', 'new_deaths_smoothed', 'total_cases_per_million', 'new_cases_per_million', 'new_cases_smoothed_per_million', 'total_deaths_per_million', 'new_deaths_per_million', 'new_deaths_smoothed_per_million', 'reproduction_rate', 'icu_patients', 'icu_patients_per_million', 'hosp_patients', 'hosp_patients_per_million', 'weekly_icu_admissions', 'weekly_icu_admissions_per_million', 'weekly_hosp_admissions', 'weekly_hosp_admissions_per_million', 'new_tests', 'total_tests', 'total_tests_per_thousand', 'new_tests_per_thousand', 'new_tests_smoothed', 'new_tests_smoothed_per_thousand', 'positive_rate', 'tests_per_case', 'tests_units', 'total_vaccinations', 'people_vaccinated', 'people_fully_vaccinated', 'total_boosters', 'new_vaccinations', 'new_vaccinations_smoothed', 'total_vaccinations_per_hundred', 'people_vaccinated_per_hundred', 'people_fully_vaccinated_per_hundred', 'total_boosters_per_hundred', 'new_vaccinations_smoothed_per_million', 'stringency_index', 'population', 'population_density', 'median_age', 'aged_65_older', 'aged_70_older', 'gdp_per_capita', 'extreme_poverty', 'cardiovasc_death_rate', 'diabetes_prevalence', 'female_smokers', 'male_smokers', 'handwashing_facilities', 'hospital_beds_per_thousand', 'life_expectancy', 'human_development_index', 'excess_mortality']
    


```python
import matplotlib.pyplot as plt
```


```python
turkeydata = data[data.location == 'Turkey']
norwaydata = data[data.location == 'Norway']
germanydata = data[data.location == 'Germany']
italydata = data[data.location == 'Italy']
```


```python
data = data[data['new_deaths'] > 0] 
data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_code</th>
      <th>continent</th>
      <th>location</th>
      <th>date</th>
      <th>total_cases</th>
      <th>new_cases</th>
      <th>new_cases_smoothed</th>
      <th>total_deaths</th>
      <th>new_deaths</th>
      <th>new_deaths_smoothed</th>
      <th>...</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
      <th>excess_mortality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>28</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-23</td>
      <td>40.0</td>
      <td>6.0</td>
      <td>2.143</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.143</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>31</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-26</td>
      <td>80.0</td>
      <td>6.0</td>
      <td>7.714</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.286</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>34</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-03-29</td>
      <td>114.0</td>
      <td>8.0</td>
      <td>11.429</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>0.571</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>39</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-04-03</td>
      <td>269.0</td>
      <td>34.0</td>
      <td>25.429</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>0.429</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>41</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-04-05</td>
      <td>299.0</td>
      <td>29.0</td>
      <td>26.429</td>
      <td>7.0</td>
      <td>2.0</td>
      <td>0.429</td>
      <td>...</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 62 columns</p>
</div>




```python
meandata = data.groupby([data['date']]).mean()
meandata['date'] = meandata.index
```


```python
plt.plot(meandata.date,meandata.new_deaths,color="red",label= "Average Deaths")
plt.plot(turkeydata.date,turkeydata.new_deaths,color="green",label= "Turkey")
plt.plot(norwaydata.date,norwaydata.new_deaths,color="blue",label= "Norway")
plt.plot(germanydata.date,germanydata.new_deaths,color="yellow",label= "Germany")
plt.plot(italydata.date,italydata.new_deaths,color="orange",label= "Italy")
plt.legend()
plt.xlabel("Date")
plt.ylabel("Deaths")
plt.show()
```


![png](output_9_0.png)



```python
location_list = [i for i in data.location]
set(location_list)
```




    {'Afghanistan',
     'Africa',
     'Albania',
     'Algeria',
     'Andorra',
     'Angola',
     'Antigua and Barbuda',
     'Argentina',
     'Armenia',
     'Asia',
     'Australia',
     'Austria',
     'Azerbaijan',
     'Bahamas',
     'Bahrain',
     'Bangladesh',
     'Barbados',
     'Belarus',
     'Belgium',
     'Belize',
     'Benin',
     'Bhutan',
     'Bolivia',
     'Bosnia and Herzegovina',
     'Botswana',
     'Brazil',
     'Brunei',
     'Bulgaria',
     'Burkina Faso',
     'Burundi',
     'Cambodia',
     'Cameroon',
     'Canada',
     'Cape Verde',
     'Central African Republic',
     'Chad',
     'Chile',
     'China',
     'Colombia',
     'Comoros',
     'Congo',
     'Costa Rica',
     "Cote d'Ivoire",
     'Croatia',
     'Cuba',
     'Cyprus',
     'Czechia',
     'Democratic Republic of Congo',
     'Denmark',
     'Djibouti',
     'Dominica',
     'Dominican Republic',
     'Ecuador',
     'Egypt',
     'El Salvador',
     'Equatorial Guinea',
     'Eritrea',
     'Estonia',
     'Eswatini',
     'Ethiopia',
     'Europe',
     'European Union',
     'Fiji',
     'Finland',
     'France',
     'Gabon',
     'Gambia',
     'Georgia',
     'Germany',
     'Ghana',
     'Greece',
     'Grenada',
     'Guatemala',
     'Guinea',
     'Guinea-Bissau',
     'Guyana',
     'Haiti',
     'Honduras',
     'Hong Kong',
     'Hungary',
     'Iceland',
     'India',
     'Indonesia',
     'International',
     'Iran',
     'Iraq',
     'Ireland',
     'Israel',
     'Italy',
     'Jamaica',
     'Japan',
     'Jordan',
     'Kazakhstan',
     'Kenya',
     'Kosovo',
     'Kuwait',
     'Kyrgyzstan',
     'Laos',
     'Latvia',
     'Lebanon',
     'Lesotho',
     'Liberia',
     'Libya',
     'Liechtenstein',
     'Lithuania',
     'Luxembourg',
     'Madagascar',
     'Malawi',
     'Malaysia',
     'Maldives',
     'Mali',
     'Malta',
     'Mauritania',
     'Mauritius',
     'Mexico',
     'Moldova',
     'Monaco',
     'Mongolia',
     'Montenegro',
     'Morocco',
     'Mozambique',
     'Myanmar',
     'Namibia',
     'Nepal',
     'Netherlands',
     'New Zealand',
     'Nicaragua',
     'Niger',
     'Nigeria',
     'North America',
     'North Macedonia',
     'Norway',
     'Oceania',
     'Oman',
     'Pakistan',
     'Palestine',
     'Panama',
     'Papua New Guinea',
     'Paraguay',
     'Peru',
     'Philippines',
     'Poland',
     'Portugal',
     'Qatar',
     'Romania',
     'Russia',
     'Rwanda',
     'Saint Kitts and Nevis',
     'Saint Lucia',
     'Saint Vincent and the Grenadines',
     'San Marino',
     'Sao Tome and Principe',
     'Saudi Arabia',
     'Senegal',
     'Serbia',
     'Seychelles',
     'Sierra Leone',
     'Singapore',
     'Slovakia',
     'Slovenia',
     'Somalia',
     'South Africa',
     'South America',
     'South Korea',
     'South Sudan',
     'Spain',
     'Sri Lanka',
     'Sudan',
     'Suriname',
     'Sweden',
     'Switzerland',
     'Syria',
     'Taiwan',
     'Tajikistan',
     'Tanzania',
     'Thailand',
     'Timor',
     'Togo',
     'Trinidad and Tobago',
     'Tunisia',
     'Turkey',
     'Uganda',
     'Ukraine',
     'United Arab Emirates',
     'United Kingdom',
     'United States',
     'Uruguay',
     'Uzbekistan',
     'Vanuatu',
     'Venezuela',
     'Vietnam',
     'World',
     'Yemen',
     'Zambia',
     'Zimbabwe'}




```python
continent_list = [i for i in data.continent]
set(continent_list)
```




    {'Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America', nan}




```python
africa_data = data[data.continent == 'Africa']
asia_data = data[data.continent == 'Asia']
europe_data = data[data.continent == 'Europe']
north_america_data = data[data.continent == 'North America']
south_america_data = data[data.continent == 'South America']
oceania_data = data[data.continent == 'Oceania']
```


```python
meandata_continent = data.groupby([data['date']]).mean()
meandata_continent['date'] = meandata.index
```


```python
plt.figure(figsize=(10,10))
plt.plot(meandata.date,meandata.new_deaths,color="red",label= "Average Deaths")
plt.plot(africa_data.date,africa_data.new_deaths,color="green",label= "Africa")
plt.plot(asia_data.date,asia_data.new_deaths,color="purple",label= "Asia")
plt.plot(europe_data.date,europe_data.new_deaths,color="blue",label= "Europe")
plt.plot(north_america_data.date,north_america_data.new_deaths,color="yellow",label= "North America")
plt.plot(south_america_data.date,south_america_data.new_deaths,color="orange",label= "South America")
plt.plot(oceania_data.date,oceania_data.new_deaths,color="grey",label= "Oceania")
plt.legend()
plt.xlabel("Date")
plt.ylabel("Deaths")
plt.show()
```


![png](output_14_0.png)



```python

```


```python

```
